import styled from "styled-components";

export const Title = styled.h1`
  color: red;
`;

export const Text = styled.p`
  color: blue;
`;
